package com.example.asmduanmau.adapter;

//public class AdapterSpinnerSach extends BaseAdapter {
//    Context context;
//
//    DAOLoaiSach daoLoaiSach;
//
//    public AdapterSpinnerSach(Context context, DAOLoaiSach daoLoaiSach) {
//        this.context = context;
//        this.daoLoaiSach = daoLoaiSach;
//    }
//
//    @Override
//    public int getCount() {
//        return datatheloai.size();
//    }
//
//    @Override
//    public Object getItem(int position) {
//        return null;
//    }
//
//    @Override
//    public long getItemId(int position) {
//        return 0;
//    }
//
//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) {
//        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
//        View v= inflater.inflate(R.layout.item_spinner,null);
//        TextView tv_spinner = convertView.findViewById(R.id.tv_spinnermaloai);
////        tv_spinner.setText(datatheloai.get(position).ge);
//
//        return v;
//    }
//}
